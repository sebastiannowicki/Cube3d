#include <stdio.h>
#include <allegro.h>
#include <math.h>
#include "mytypes.h"
#include "math3d.c"
#include <math.h>

#define NOP 8      //ilosc punktow
#define NOF 12     //ilosc facow
#define NOS 6
#define VALUE 100

float dangle=0.0;

vector v={0.0, 0.0, 1.0};
vector u={320.0, 0.0, 0.0};
vector w={0.0, 240.0, 0.0};
point E={0.0, 0.0, -20.0};
vector EP;
float EP_dot_v;
float one;
float angle_x=0, angle_y=0, angle_z=0;
int pers_flag=1;
int wirframe_flag=0;
extern float tsin[3600];
extern float tcos[3600];

extern point *pt;

float tr_x=0, tr_y=0, tr_z=0;
float rz1=356, rz2=256, rz3=256;



void keys(void);
void remind(point *s, point *d, int nop);
void calculate2D(point *p, int nop);
void calculate2D_2(point *p, int nop);
void make_tables(void);
void print(BITMAP *bitmap);
void drawWall(BITMAP *bitmap, point *p, int s[6][4], int nos);



int main()
{
BITMAP *bitmap;
point *p_rob, *p_org;
int s[6][4];

p_rob=(point *)malloc(NOP*sizeof(point));
p_org=(point *)malloc(NOP*sizeof(point));
pt=(point *)malloc(NOP*sizeof(point));

p_org[0].x=-VALUE; p_org[0].y= VALUE;  p_org[0].z=-VALUE;
p_org[1].x= VALUE; p_org[1].y= VALUE;  p_org[1].z=-VALUE;
p_org[2].x= VALUE; p_org[2].y=-VALUE;  p_org[2].z=-VALUE;
p_org[3].x=-VALUE; p_org[3].y=-VALUE;  p_org[3].z=-VALUE;
p_org[4].x=-VALUE; p_org[4].y= VALUE;  p_org[4].z= VALUE;
p_org[5].x= VALUE; p_org[5].y= VALUE;  p_org[5].z= VALUE;
p_org[6].x= VALUE; p_org[6].y=-VALUE;  p_org[6].z= VALUE;
p_org[7].x=-VALUE; p_org[7].y=-VALUE;  p_org[7].z= VALUE;

s[0][0]=0; s[0][1]=1; s[0][2]=2; s[0][3]=3;
s[1][0]=1; s[1][1]=5; s[1][2]=6; s[1][3]=2;
s[2][0]=5; s[2][1]=4; s[2][2]=7; s[2][3]=6;
s[3][0]=4; s[3][1]=0; s[3][2]=3; s[3][3]=7;
s[4][0]=3; s[4][1]=2; s[4][2]=6; s[4][3]=7;
s[5][0]=4; s[5][1]=5; s[5][2]=1; s[5][3]=0;


make_tables();
allegro_init();
install_keyboard();
install_mouse();
set_color_depth(16);

set_gfx_mode(GFX_DIRECTX_ACCEL, 640, 480, 0, 0);
bitmap=create_bitmap(SCREEN_W, SCREEN_H);
clear(bitmap);





//while(!key[KEY_ESC])
for(angle_x=angle_y=angle_z=0.0;;angle_x+=dangle, angle_y+=dangle, angle_z+=dangle)
  {
     if(angle_x>=359.0) while(angle_x>359.0) angle_x-=359.0;
     if(angle_y>=359.0) while(angle_y>359.0) angle_y-=359.0;
     if(angle_z>=359.0) while(angle_z>359.0) angle_z-=359.0;
	 if(angle_x<0.0) while(angle_x<0.0) angle_x+=359.0;
	 if(angle_y<0.0) while(angle_y<0.0) angle_y+=359.0;
	 if(angle_z<0.0) while(angle_z<0.0) angle_z+=359.0;
     
     keys();

     if(key[KEY_ESC]) break;

     remind(p_org, p_rob, NOP);
     rotateX(p_rob, angle_x, NOP);
     rotateY(p_rob, angle_y, NOP);
     rotateZ(p_rob, angle_z, NOP);
     scale(p_rob, 1.0, 1.0, 1.0, NOP);
     translate(p_rob, tr_x, tr_y, tr_z, NOP);
     calculate2D(p_rob, NOP);
     clear(bitmap);
     print(bitmap);
     drawWall(bitmap, p_rob, s, NOS);

}



free(p_org);
free(p_rob);
free(pt);
return 0;
}
END_OF_MAIN();


void remind(point *s, point *d, int nop)
{
 int index;
  for(index=0;index<nop;index++)
     {
        d[index].x=s[index].x;
        d[index].y=s[index].y;
        d[index].z=s[index].z;
     }
}

void calculate2D(point *p, int nop)
{
  int index;
  float temp;

  for(index=0;index<nop;index++)
     {
      if(pers_flag)
      {
        temp=1.0/(p[index].z+rz1);
        pt[index].x=(p[index].x*rz2)*temp;
        pt[index].y=(p[index].y*rz3)*temp;
      }
    }

  for(index=0;index<nop;index++)
  {
    p[index].x=pt[index].x;
    p[index].y=pt[index].y;
  }
}


void make_tables(void)
{
int index;
float i;
float angle=0;

for(index=0, i=0.0;index<3600;index++, i+=1.0)
 {
   angle=i*0.1;
   tsin[index]=sin(angle*piover180);
   tcos[index]=cos(angle*piover180);
 }
}

void calculate2D_2(point *p, int nop)
{
 int index;

 for(index=0;index<nop;index++)
   {
      p[index].z*=-1.0;
      EP=make_vector(E, p[index]);
      EP_dot_v=dot_vectors(EP, v);
      pt[index].x=dot_vectors(EP, normalize(u))/EP_dot_v;
      pt[index].y=dot_vectors(EP, normalize(w))/EP_dot_v;
   }

for(index=0;index<nop;index++)
 {
  p[index].x=pt[index].x;
  p[index].y=pt[index].y;
  p[index].z=0.0;
 }
}

void print(BITMAP *bitmap)
{
textprintf(bitmap, font, 0, 0, makecol(255, 255, 255) ,"tr_x=%5.2f tr_y=%5.2f tr_z=%5.2f", tr_x, tr_y, tr_z);
textprintf(bitmap, font, 0, 10, makecol(255, 255, 255) ,"rz1=%5.2f rz2=%5.2f rz3=%5.2f", rz1, rz2, rz3);
textprintf(bitmap, font, 0, 20, makecol(255, 255, 255) ,"angle_x=%5.2f angle_y=%5.2f angle_z=%5.2f", angle_x, angle_y, angle_z);
textprintf(bitmap, font, 0, 30, makecol(255, 255, 255) ,"dangle=%5.2f", dangle);
//textprintf(bitmap, font, 0, 30, makecol(255, 255, 255) ,"E.x=%5.2f E.y=%5.2f E.z=%5.2f", E.x, E.y, E.z);
//textprintf(bitmap, font, 0, 40, makecol(255, 255, 255) ,"v.x=%5.2f v.y=%5.2f v.z=%5.2f", v.x, v.y, v.z);
//textprintf(bitmap, font, 0, 50, makecol(255, 255, 255) ,"u.x=%5.2f u.y=%5.2f u.z=%5.2f", u.x, u.y, u.z);
//textprintf(bitmap, font, 0, 60, makecol(255, 255, 255) ,"w.x=%5.2f w.y=%5.2f w.z=%5.2f", w.x, w.y, w.z);
}


void drawWall(BITMAP *bitmap, point *p, int s[6][4], int nos)
{
  int index;
  float ans;
  vector vz={0.0, 0.0, 1.0};
  vector v1, v2, v;
  int poly[10];

for(index=0;index<nos;index++)
   {                        //index
      v1=make_vector(p[s[index][0]], p[s[index][1]]);   //dwa wektory ze sciany
      v2=make_vector(p[s[index][1]], p[s[index][2]]);
      v=normalize(cross_vectors(v1, v2));    //ich iloczyn wektotowy oraz normalizacja
      ans=dot_vectors(v, vz);

//      textprintf(bitmap, font, 0, 70, makecol(255, 255, 255) ,"v1.x=%5.2f v1.y=%5.2f v1.z=%5.2f", v1.x, v1.y, v1.z);
//      textprintf(bitmap, font, 0, 80, makecol(255, 255, 255) ,"v2.x=%5.2f v2.y=%5.2f v2.z=%5.2f", v2.x, v2.y, v2.z);
 //     textprintf(bitmap, font, 0, 90, makecol(255, 255, 255) ,"v.x =%5.2f v.y =%5.2f v.z =%5.2f", v.x, v.y, v.z);
 //     textprintf(bitmap, font, 0, 100, makecol(255, 255, 255) ,"ans=%5.2f", ans);

      if(ans< 0.0) {
          if(wirframe_flag) { 
		   line(bitmap, (int)(p[s[index][0]].x+320), (int)(p[s[index][0]].y+240), (int)(p[s[index][1]].x+320), (int)(p[s[index][1]].y+240), makecol16(255, 255, 255));
           line(bitmap, (int)(p[s[index][1]].x+320), (int)(p[s[index][1]].y+240), (int)(p[s[index][2]].x+320), (int)(p[s[index][2]].y+240), makecol16(255, 255, 255));
           line(bitmap, (int)(p[s[index][2]].x+320), (int)(p[s[index][2]].y+240), (int)(p[s[index][3]].x+320), (int)(p[s[index][3]].y+240), makecol16(255, 255, 255));
           line(bitmap, (int)(p[s[index][3]].x+320), (int)(p[s[index][3]].y+240), (int)(p[s[index][0]].x+320), (int)(p[s[index][0]].y+240), makecol16(255, 255, 255));
		  }  
		  else { 
		     poly[0]=(int)(p[s[index][0]].x+320);
             poly[1]=(int)(p[s[index][0]].y+240);
             poly[2]=(int)(p[s[index][1]].x+320);
             poly[3]=(int)(p[s[index][1]].y+240);
             poly[4]=(int)(p[s[index][2]].x+320);
             poly[5]=(int)(p[s[index][2]].y+240);
             poly[6]=(int)(p[s[index][3]].x+320);
             poly[7]=(int)(p[s[index][3]].y+240);
             poly[8]=(int)(p[s[index][0]].x+320);
             poly[9]=(int)(p[s[index][0]].y+240);
             polygon(bitmap, 5, poly, makecol16(200+(9*index), 200+(9*index), 200+(4*index)));
		  }


         }
   }

//for(index=0;index<8;index++)
  //textprintf(bitmap, font, (int)p[index].x+320, (int)p[index].y+240, makecol(255, 0, 0) ,"%d", index);

   blit(bitmap, screen, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
}


void keys(void)
{
     if(key[KEY_Q]) tr_x+=2;
     if(key[KEY_W]) tr_x-=2;

     if(key[KEY_A]) tr_y+=2;
     if(key[KEY_S]) tr_y-=2;

     if(key[KEY_Z]) tr_z+=2;
     if(key[KEY_X]) tr_z-=2;

     if(key[KEY_E]) rz1++;
     if(key[KEY_R]) rz1--;

     if(key[KEY_D]) rz2++;
     if(key[KEY_F]) rz2--;

     if(key[KEY_C]) rz3++;
     if(key[KEY_V]) rz3--;

     if(key[KEY_T]) v.x++;
     if(key[KEY_Y]) v.x--;

     if(key[KEY_G]) v.y++;
     if(key[KEY_H]) v.y--;

     if(key[KEY_B]) v.z++;
     if(key[KEY_N]) v.z--;

     if(key[KEY_1]) u.x++;
     if(key[KEY_2]) u.x--;
     if(key[KEY_3]) u.y++;
     if(key[KEY_4]) u.y--;
     if(key[KEY_5]) u.z++;
     if(key[KEY_6]) u.z--;

     if(key[KEY_F1]) w.x++;
     if(key[KEY_F2]) w.x--;
     if(key[KEY_F3]) w.y++;
     if(key[KEY_F4]) w.y--;
     if(key[KEY_F5]) w.z++;
     if(key[KEY_F6]) w.z--;

     if(key[KEY_4_PAD]) angle_x--;
     if(key[KEY_6_PAD]) angle_x++;

     if(key[KEY_8_PAD]) angle_y--;
     if(key[KEY_2_PAD]) angle_y++;

     if(key[KEY_1_PAD]) angle_z--;
     if(key[KEY_9_PAD]) angle_z++;

     if(key[KEY_F7]) pers_flag=1;
     if(key[KEY_F8]) pers_flag=0;

     if(key[KEY_F9]) wirframe_flag=1;
	 if(key[KEY_F10]) wirframe_flag=0;
	 
	 if(key[KEY_UP]) dangle+=0.1;
     if(key[KEY_DOWN]) dangle-=0.1;


     }

