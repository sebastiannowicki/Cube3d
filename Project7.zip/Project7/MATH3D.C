const float piover180=3.141592/180;

float tsin[3600];
float tcos[3600];



void rotateX(point *p, float angle, int nop);
void rotateY(point *p, float angle, int nop);
void rotateZ(point *p, float angle, int nop);
void translate(point *p, float tx, float ty, float tz, int nop);
void scale(point *p, float sx, float sy, float sz, int nop);
vector normalize(vector v);
float dot_vectors(vector v1, vector v2);
vector cross_vectors(vector v1, vector v2);
vector add_vecors(vector v1, vector v2);
vector sub_vecors(vector v1, vector v2);
vector make_vector(point p1, point p2);
int calc_index(float angle);
float calc_angle(vector v1, vector v2);

point *pt;

void rotateX(point *p, float angle, int nop)
{

 int index;
 float mysin, mycos;

 mysin=tsin[calc_index(angle)];
 mycos=tcos[calc_index(angle)];

 for(index=0;index<nop;index++)
   {
    pt[index].x=p[index].x;
    pt[index].y=mycos*p[index].y-(mysin*p[index].z);
    pt[index].z=mysin*p[index].y+(mycos*p[index].z);
   }
  for(index=0;index<nop;index++)
   {
     p[index].x=pt[index].x;
     p[index].y=pt[index].y;
     p[index].z=pt[index].z;
   }

}


void rotateY(point *p, float angle, int nop)
{
 int index;
 float mysin, mycos;

 mysin=tsin[calc_index(angle)];
 mycos=tcos[calc_index(angle)];

 for(index=0;index<nop;index++)
   {
    pt[index].x=mycos*p[index].x+(mysin*p[index].z);
    pt[index].y=p[index].y;
    pt[index].z=-mysin*p[index].x+(mycos*p[index].z);
   }
  for(index=0;index<nop;index++)
   {
     p[index].x=pt[index].x;
     p[index].y=pt[index].y;
     p[index].z=pt[index].z;
   }

}

void rotateZ(point *p, float angle, int nop)
{
 int index;
 float mysin, mycos;

 mysin=tsin[calc_index(angle)];
 mycos=tcos[calc_index(angle)];

 for(index=0;index<nop;index++)
   {
    pt[index].x=p[index].x*mycos-(mysin*p[index].y);
    pt[index].y=p[index].x*mysin+(mycos*p[index].y);
    pt[index].z=p[index].z;
   }
  for(index=0;index<nop;index++)
   {
     p[index].x=pt[index].x;
     p[index].y=pt[index].y;
     p[index].z=pt[index].z;
   }
}

void translate(point *p, float tx, float ty, float tz, int nop)
{
 int index;
 for(index=0;index<nop;index++)
   {
     p[index].x+=tx;
     p[index].y+=ty;
     p[index].z+=tz;
   }
}

void scale(point *p, float sx, float sy, float sz, int nop)
{
 int index;
 for(index=0;index<nop;index++)
  {
     p[index].x*=sx;
     p[index].y*=sy;
     p[index].z*=sz;
  }
}


vector normalize(vector v)
{
 vector ret;
 float t=1/sqrt((v.x*v.x)+(v.y*v.y)+(v.z*v.z));
 ret.x=v.x*t;
 ret.y=v.y*t;
 ret.z=v.z*t;
return ret;
}

float dot_vectors(vector v1, vector v2)
{
 vector v;
 v.x=v1.x*v2.x;
 v.y=v1.y*v2.y;
 v.z=v1.z*v2.z;
 return (v.x+v.y+v.z);
}

vector add_vecors(vector v1, vector v2)
{
 vector v;
 v.x=v1.x+v2.x;
 v.y=v1.x+v2.y;
 v.z=v1.x+v2.z;
 return v;
}

vector sub_vecors(vector v1, vector v2)
{
 vector v;
 v.x=v1.x-v2.x;
 v.y=v1.x-v2.y;
 v.z=v1.x-v2.z;
 return v;
}



int calc_index(float angle)
{
  return (int)(angle*10.0);
}

vector make_vector(point p1, point p2)
{
 vector v;
 v.x=p2.x-p1.x;
 v.y=p2.y-p1.y;
 v.z=p2.z-p1.z;
 return v;
}

vector cross_vectors(vector v1, vector v2)
{
   vector v;
   v.x=(v1.y * v2.z) - (v1.z * v2.y);
   v.y=(v1.z * v2.x) - (v1.x * v2.z);
   v.z=(v1.x * v2.y) - (v1.y * v2.x);
return v;
}

float calc_angle(vector v1, vector v2)
{
 float angle;
 float licz, mian;
 float l1, l2;

 licz=dot_vectors(v1, v2);
 l1=sqrt( (v1.x*v1.x)+(v1.y+v1.y) + (v1.z+v1.z) );
 l2=sqrt( (v2.x*v2.x)+(v2.y+v2.y) + (v2.z+v2.z) );
 mian=l1*l2;

 angle=acos(licz/mian);
 angle*=(1.0/piover180);
 return angle;
}




